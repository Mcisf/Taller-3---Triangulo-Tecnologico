package com.example.taller3_eltriangulo.Datos

class Datos {
    companion object{
        val MY_PERMISSION_REQUEST_CAMARA_LOCATION = 22
        val MY_PERMISSION_REQUEST_LOCATION = 55
    }

    data class Location(val latitud: Double, val longitud: Double, val nombre: String)
}