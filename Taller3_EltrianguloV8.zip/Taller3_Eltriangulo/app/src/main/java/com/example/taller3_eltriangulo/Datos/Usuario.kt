package com.example.taller3_eltriangulo.Datos

class Usuario {
    var uid: String = ""
    val nombre: String = ""
    val apellido: String = ""
    val noIdentificacion: String = ""
    val latitud: Double = 0.0
    val longitud: Double = 0.0
    var estado: Boolean = true
    val profileImgUrl: String = ""
}