package com.example.taller3_eltriangulo.Logica

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Criteria
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.taller3_eltriangulo.Datos.Datos
import com.example.taller3_eltriangulo.R
import com.example.taller3_eltriangulo.databinding.ActivityPantallaRegistroBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class pantallaRegistro : AppCompatActivity() {

    private lateinit var binding: ActivityPantallaRegistroBinding
    private lateinit var bdRealtime: FirebaseDatabase
    private lateinit var locationManager: LocationManager
    private lateinit var storageReference: StorageReference // Firebase Storage reference
    private lateinit var captureImageLauncher: ActivityResultLauncher<Intent>
    private lateinit var pickImageLauncher: ActivityResultLauncher<Intent>
    private var imageUri: Uri? = null
    private var currentLatitude: Double = 0.0
    private var currentLongitude: Double = 0.0
    private var profileImgUrl: String = "" // URL de la imagen de perfil
    private var permisos = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    )
    private val permisoCamara = 1
    private val permisoGaleria = 2
    private val permisoCodigo = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa el ViewBinding y Firebase Storage
        binding = ActivityPantallaRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)
        bdRealtime = FirebaseDatabase.getInstance()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        storageReference = FirebaseStorage.getInstance().reference.child("user_images")

        // Pide los permisos necesarios
        pedirPermiso(this, permisos, "Se necesitan estos permisos para todas las funcionalidades de la app", Datos.MY_PERMISSION_REQUEST_CAMARA_LOCATION)

        // Configura el comportamiento de los botones
        registrar()

        // Inicializa el lanzador para capturar y seleccionar imágenes
        manejoFotoPerfil()
    }

    private fun registrar() {
        binding.botonRegistrarUsuario.setOnClickListener {
            // Llama a getLastKnownLocation para actualizar las coordenadas
            getLastKnownLocation()

            val nombre = binding.editNombre.text.toString().trim()
            val apellido = binding.editApellido.text.toString().trim()
            val email = binding.editEmail.text.toString()
            val password = binding.editPassword.text.toString()
            val cedula = binding.editNumero.text.toString().trim()
            // val estado = true // Por ejemplo, el estado inicial es activo

            if (isEmailValid(email) && validateForm()) {
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password).addOnCompleteListener {
                    if (it.isSuccessful) {
                        Toast.makeText(this, "Se registró correctamente", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No se pudo registrar el usuario", Toast.LENGTH_SHORT).show()
                    }
                }

                val referenciaRealtime = bdRealtime.getReference("usuarios")
                val user = hashMapOf(
                    "nombre" to nombre,
                    "apellido" to apellido,
                    "numero" to cedula,
                    "contraseña" to password,
                    "latitud" to currentLatitude,
                    "longitud" to currentLongitude,
                    //"estado" to estado,
                    "profileImgUrl" to profileImgUrl // URL de la imagen de perfil cargada
                )

                val emailSanitizado = email.replace(".", "_").replace("@", "_at_")
                referenciaRealtime.child(emailSanitizado).setValue(user).addOnSuccessListener {
                    Toast.makeText(this, "Datos guardados en BD", Toast.LENGTH_SHORT).show()
                }.addOnFailureListener {
                    Toast.makeText(this, "Error al guardar en BD", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Llene los campos por favor", Toast.LENGTH_SHORT).show()
            }
        }

        binding.botonVolverAiniciarSesion.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        binding.botonSubirFoto.setOnClickListener {
            if (revisarPermisos()) {
                galeria()
            } else {
                pedirPermisos()
            }
        }

        binding.botonTomarFoto.setOnClickListener {
            if (revisarPermisos()) {
                camara()
            } else {
                pedirPermisos()
            }
        }
    }

    private fun subirImagenAFirebase(uri: Uri) {
        val fileReference = storageReference.child("profile_${System.currentTimeMillis()}.jpg")
        fileReference.putFile(uri)
            .addOnSuccessListener {
                fileReference.downloadUrl.addOnSuccessListener { url ->
                    profileImgUrl = url.toString() // Guarda la URL para usarla en el registro
                    Toast.makeText(this, "Imagen subida correctamente", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al subir la imagen", Toast.LENGTH_SHORT).show()
                Log.e("FirebaseStorage", "Error al subir la imagen", it)
            }
    }

    private fun isEmailValid(email: String) = email.contains("@") && email.contains(".") && email.length >= 5

    private fun validateForm(): Boolean {
        var valid = true
        val email = binding.editEmail.text.toString()
        if (TextUtils.isEmpty(email)) {
            binding.editEmail.error = "Required."
            valid = false
        } else {
            binding.editEmail.error = null
        }

        val password = binding.editPassword.text.toString()
        if (TextUtils.isEmpty(password)) {
            binding.editPassword.error = "Required."
            valid = false
        } else {
            binding.editPassword.error = null
        }
        return valid
    }

    private fun pedirPermiso(context: Activity, permisos: Array<String>, justificacion: String, idCode: Int) {
        if (permisos.any { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }) {
            permisos.forEach { permiso ->
                if (ActivityCompat.shouldShowRequestPermissionRationale(context, permiso)) {
                    Toast.makeText(this, "Se necesita permiso para esta función", Toast.LENGTH_SHORT).show()
                }
            }
            ActivityCompat.requestPermissions(context, permisos, idCode)
        } else {
            getLastKnownLocation()
        }
    }

    private fun pedirPermisos() {
        ActivityCompat.requestPermissions(
            this,
            permisos,
            permisoCodigo
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == Datos.MY_PERMISSION_REQUEST_CAMARA_LOCATION &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            Toast.makeText(this, "¡Gracias!", Toast.LENGTH_SHORT).show()
            getLastKnownLocation()
        } else {
            Toast.makeText(this, "Funcionalidades limitadas", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getLastKnownLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val provider = locationManager.getBestProvider(Criteria(), false)
            val location = provider?.let { locationManager.getLastKnownLocation(it) }
            if (location != null) {
                currentLatitude = location.latitude
                currentLongitude = location.longitude
                Log.d("Location", "Latitude: $currentLatitude, Longitude: $currentLongitude")
            } else {
                Log.d("Location", "Location not available")
            }
        } else {
            Toast.makeText(this, "Permisos de ubicación no concedidos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun camara() {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.TITLE, "Imagen")
            put(MediaStore.Images.Media.DESCRIPTION, "Cámara")
        }
        imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
        startActivityForResult(intent, permisoCamara)
    }

    private fun galeria() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, permisoGaleria)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                permisoCamara -> {
                    binding.imagenRegistro.setImageURI(imageUri)
                    imageUri?.let { subirImagenAFirebase(it) } // Sube la imagen capturada
                }
                permisoGaleria -> {
                    val uriSelect: Uri? = data?.data
                    if (uriSelect != null) {
                        imageUri = uriSelect
                        binding.imagenRegistro.setImageURI(uriSelect)
                        subirImagenAFirebase(uriSelect) // Sube la imagen seleccionada
                    }
                }
            }
        }
    }

    private fun revisarPermisos(): Boolean {
        val permisoCamara = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
        val lecturaAlmacen = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
        val escrituraAlmacen = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        return permisoCamara == PackageManager.PERMISSION_GRANTED &&
                lecturaAlmacen == PackageManager.PERMISSION_GRANTED &&
                escrituraAlmacen == PackageManager.PERMISSION_GRANTED
    }

    private fun manejoFotoPerfil() {
        captureImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val imageBitmap = data?.extras?.get("data") as? Bitmap
                if (imageBitmap != null) {
                    binding.imagenRegistro.setImageBitmap(imageBitmap)
                    imageUri = getImageUriFromBitmap(imageBitmap)
                    imageUri?.let { subirImagenAFirebase(it) }
                } else {
                    Toast.makeText(this, "Error al capturar la imagen", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Captura de imagen cancelada", Toast.LENGTH_SHORT).show()
            }
        }

        pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                imageUri = result.data?.data
                binding.imagenRegistro.setImageURI(imageUri)
                imageUri?.let { subirImagenAFirebase(it) }
            }
        }
    }

    private fun getImageUriFromBitmap(bitmap: Bitmap): Uri? {
        val imageFolder = File(cacheDir, "images")
        var uri: Uri? = null
        try {
            imageFolder.mkdirs()
            val file = File(imageFolder, "captured_image_${System.currentTimeMillis()}.jpg")
            val stream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
            stream.flush()
            stream.close()
            uri = FileProvider.getUriForFile(this, "${packageName}.provider", file)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return uri
    }
}
