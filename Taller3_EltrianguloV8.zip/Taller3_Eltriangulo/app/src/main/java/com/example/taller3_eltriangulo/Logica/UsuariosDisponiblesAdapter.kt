package com.example.taller3_eltriangulo.Logica

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler
import com.bumptech.glide.Glide
import com.example.taller3_eltriangulo.Datos.Usuario
import com.example.taller3_eltriangulo.databinding.ItemUserBinding

class UsuariosDisponiblesAdapter (private val userList : List<Usuario>,
                                  private val onLocationClick: (Usuario) -> Unit
):RecyclerView.Adapter<UsuariosDisponiblesAdapter.UserViewHolder>() {

    inner class UserViewHolder(val binding: ItemUserBinding) :RecyclerView.ViewHolder(binding.root){
        fun bind(usuario: Usuario){
            binding.nombreCompletoUsuario.text = "${usuario.nombre} ${usuario.apellido}"
            Glide.with(binding.root.context)
                .load(usuario.profileImgUrl)
                .into(binding.imagenUsuario)
            binding.btnViewLocation.setOnClickListener{
                onLocationClick(usuario)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        holder.bind(userList[position])
    }

    override fun getItemCount(): Int = userList.size
}