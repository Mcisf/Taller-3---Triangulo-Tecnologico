package com.example.taller3_eltriangulo.Logica

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.taller3_eltriangulo.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser


class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var campoEmail: EditText
    private lateinit var campoPassword: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()
        campoEmail = findViewById(R.id.campoEmail)
        campoPassword = findViewById(R.id.campoPassword)

        val botonRegistarse:Button = findViewById(R.id.botonRegistrarse)
        val botonIngresar: Button = findViewById(R.id.botonIngresar)
        botonRegistarse.setOnClickListener{
            val intentRegister = Intent(this, pantallaRegistro::class.java)
            startActivity(intentRegister)
        }

        botonIngresar.setOnClickListener{
            val camposLlenados = validateForm()
            if(camposLlenados){
                auth.signInWithEmailAndPassword(campoEmail.text.toString(),
                    campoPassword.text.toString())
                    .addOnCompleteListener(this) { task ->

                        Log.d(TAG, "signInWithEmail:onComplete:" + task.isSuccessful)
                        updateUI(auth.currentUser)
                        if (!task.isSuccessful) {
                            Log.w(TAG, "signInWithEmail:failure", task.exception)
                            Toast.makeText(this, "Authentication failed.",
                                Toast.LENGTH_SHORT).show()
                            campoEmail.setText("")
                            campoPassword.setText("")
                        }
                    }
            }

        }


    }

    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }

    private fun updateUI(currentUser: FirebaseUser?) {
        if (currentUser != null) {
            val intent = Intent(this, MapaConGoogle::class.java)
            intent.putExtra("user", currentUser.email)
            startActivity(intent)
        } else {
            campoEmail.setText("")
            campoPassword.setText("")
        }
    }
    private fun validateForm(): Boolean {
        var valid = true
        val email = campoEmail.text.toString()
        if (TextUtils.isEmpty(email)) {
            campoEmail.error = "Required."
            valid = false
        } else {
            campoEmail.error = null
        }
        val password = campoPassword.text.toString()
        if (TextUtils.isEmpty(password)) {
            campoPassword.error = "Required."
            valid = false
        } else {
            campoPassword.error = null
        }
        return valid
    }



}