package com.example.taller3_eltriangulo.Logica

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.taller3_eltriangulo.Datos.Usuario
import com.example.taller3_eltriangulo.R
import com.example.taller3_eltriangulo.databinding.ActivityUsuariosDisponiblesBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import java.io.File

class UsuariosDisponibles : AppCompatActivity() {

    private lateinit var binding: ActivityUsuariosDisponiblesBinding
    private lateinit var database:DatabaseReference
    private lateinit var auth: FirebaseAuth
    private val userList = mutableListOf<Usuario>()
    private lateinit var adapter: UsuariosDisponiblesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =ActivityUsuariosDisponiblesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        database= FirebaseDatabase.getInstance().getReference("usuarios")

        recyclerView()
        cargarUsuarios()

    }

    private fun recyclerView(){
        adapter = UsuariosDisponiblesAdapter(userList){
                usuario ->

            val intent=Intent(this, MapaUsuario::class.java)
            intent.putExtra("userId", usuario.uid)
            startActivity(intent)
        }
        binding.vistaUsuarios.layoutManager = LinearLayoutManager(this)
        binding.vistaUsuarios.adapter = adapter

    }

    private fun cargarUsuarios() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                userList.clear()
                val currentUserId = auth.currentUser?.uid
                for (userSnapshot in snapshot.children) {
                    val user = userSnapshot.getValue(Usuario::class.java)
                    user?.let {
                        if (it.uid.isEmpty()) {
                            it.uid = userSnapshot.key ?: ""  // Asigna el uid desde la clave de userSnapshot
                        }
                        if (it.uid != currentUserId && it.estado == true) {
                            userList.add(it)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Manejo del error
            }
        })
    }


}
