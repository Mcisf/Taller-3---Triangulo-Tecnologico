package com.example.taller3_eltriangulo.Logica

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Geocoder
import com.google.android.gms.location.LocationRequest
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.taller3_eltriangulo.Datos.Datos
import com.example.taller3_eltriangulo.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.taller3_eltriangulo.databinding.ActivityMapaConGoogleBinding
import com.google.android.gms.maps.model.MapStyleOptions
import java.io.IOException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import org.json.JSONObject
import java.io.InputStream

class MapaConGoogle : AppCompatActivity(), OnMapReadyCallback {


    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapaConGoogleBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sensorManager: SensorManager
    private lateinit var lightSensor: Sensor
    private lateinit var lightSensorListener: SensorEventListener
    private lateinit var  direccion : EditText
    private var posicionActual : LatLng = LatLng(0.0,0.0)
    private var latitud : Double = 0.0
    private var longitud : Double = 0.0
    private lateinit var locationCallback: LocationCallback
    private lateinit var posicionLocation: ArrayList<Datos.Location>
    private lateinit var auth: FirebaseAuth
    private  lateinit var bdRealtime : FirebaseDatabase




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        binding = ActivityMapaConGoogleBinding.inflate(layoutInflater)
        setContentView(binding.root)
        direccion = binding.direccion

        binding = ActivityMapaConGoogleBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)!!
        posicionLocation = ArrayList()
        auth = FirebaseAuth.getInstance()
        bdRealtime = FirebaseDatabase.getInstance()


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        if (savedInstanceState == null) {
            val mapFragment = SupportMapFragment.newInstance()
            supportFragmentManager.beginTransaction()
                .replace(R.id.map_container, mapFragment)
                .commit()
            mapFragment.getMapAsync(this)
        }


        lightSensorListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (mMap != null) {
                    val context = this@MapaConGoogle // Obtener el contexto de la actividad
                    val luxValue = event.values[0]

                    // Ajustar el umbral según tus necesidades
                    val threshold = 10000

                    if (luxValue < threshold) {
                        Log.i("MAPS", "DARK MAP: $luxValue")
                        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(context, R.raw.style_noche))
                    } else {
                        Log.i("MAPS", "LIGHT MAP: $luxValue")
                        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(context, R.raw.style_retro))
                    }
                }
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
        }


        val json = JSONObject(loadJSONFromAsset())
        val destinosJson = json.getJSONArray("locationsArray")
        for(i in 0 until destinosJson.length()){
            val jsonObject =destinosJson.getJSONObject(i)

            val posicionLocationNueva = Datos.Location(
                latitud = jsonObject.getDouble("latitude"),
                longitud = jsonObject.getDouble("longitude"),
                nombre =  jsonObject.getString("name")
            )

            // Agregar la nueva posición a la lista
            posicionLocation.add(posicionLocationNueva)
        }




    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
// Handle item selection
        return when (item.itemId) {
            R.id.menuLogOut -> {
                auth.signOut()
                val intent = Intent(this, MainActivity::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
                true
            }
            R.id.menuActivarUsuario -> {
                val referenciaRealtime = bdRealtime.getReference("usuarios")
                val userreference = FirebaseAuth.getInstance().currentUser
                val email = userreference?.email

                val emailSanitizado = email.toString().replace(".", "_").replace("@", "_at_")
                val userStatusRef = referenciaRealtime.child(emailSanitizado).child("Estado")
                // Leer el valor actual de "Estado"
                userStatusRef.get().addOnSuccessListener { snapshot ->
                    val currentStatus = snapshot.getValue(String::class.java)  // Puede ser "Activo", "Inactivo" o null si no existe
                    val newStatus = if (currentStatus == "Activo") "Inactivo" else "Activo"  // Cambia entre Activo e Inactivo
                    val update = HashMap<String, Any>()
                    update["Estado"] = newStatus

                    // Actualizar el estado en la base de datos
                    referenciaRealtime.child(emailSanitizado).updateChildren(update)
                        .addOnCompleteListener {
                            // Muestra un mensaje de éxito con el nuevo estado
                            Toast.makeText(this, "Estado cambiado a $newStatus", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Error al actualizar el estado", Toast.LENGTH_SHORT).show()
                        }
                }.addOnFailureListener {
                    Toast.makeText(this, "Error al leer el estado actual", Toast.LENGTH_SHORT).show()
                }
                true
            }
            R.id.menuDisponibles -> {
                val intent = Intent(this, UsuariosDisponibles::class.java)
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }



    override fun onResume() {
        super.onResume()
        sensorManager.registerListener(lightSensorListener, lightSensor,
            SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(lightSensorListener)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomGesturesEnabled = true
        mMap.uiSettings.isZoomControlsEnabled = true

        val permisos = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BODY_SENSORS)
        pedirPermiso(
            this, permisos, "Se necesitan estos permisos para todas las funcionalidades de la app",
            Datos.MY_PERMISSION_REQUEST_LOCATION
        )
        // Add a marker in Sydney and move the camera
        //4.628754841501681, -74.06465377597839

        for(i in 0 until posicionLocation.size){
            val posicion = LatLng(posicionLocation[i].latitud, posicionLocation[i].longitud)
            mMap.addMarker(
                MarkerOptions().position(posicion).title(posicionLocation[i].nombre)
            )
        }

        direccion.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                val address = direccion.text.toString()
                colocarMarcador(address)
                return@setOnEditorActionListener true
            }
            false
        }

        mMap.setOnMapClickListener { latLng ->
            val geocoder = Geocoder(this@MapaConGoogle)
            val address = geocoder.getFromLocation(latLng.latitude, latLng.longitude,1)?.firstOrNull()
                ?.getAddressLine(0) ?: "Dirección desconocida"
            mMap.addMarker(MarkerOptions().position(latLng).title(address))
            var distancia = 0.0
            distancia = calcularDistancia(latLng,posicionActual)
            Toast.makeText(this, "la distancia entre el punto de partida y este es: ${distancia}km",
                Toast.LENGTH_SHORT).show()

        }


    }

    private fun obtenerUbicacionActual(callback: (Double, Double) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    latitud = location.latitude
                    longitud = location.longitude
                    callback(latitud, longitud)
                } else {
                    Toast.makeText(this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener {
                Log.d("Location", "Error al obtener la ubicación: ${it.message}")
            }
        } else {
            Toast.makeText(this, "Permisos de ubicación no concedidos", Toast.LENGTH_SHORT).show()
        }
    }

    fun pedirPermiso(context: Activity, permisos: Array<String>, justificacion: String, idCode: Int) {


        if(ContextCompat.checkSelfPermission(context,permisos[0]) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context,permisos[1]) != PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(context, permisos[0])) {
                Toast.makeText(this, "se necesita permiso para esta funcion", Toast.LENGTH_SHORT).show()
                ActivityCompat.requestPermissions(context, arrayOf(permisos[0]), idCode)
            }
            if(ActivityCompat.shouldShowRequestPermissionRationale(context,permisos[1])){
                Toast.makeText(this, "se necesita permiso para esta funcion", Toast.LENGTH_SHORT).show()
                ActivityCompat.requestPermissions(context, arrayOf(permisos[1]), idCode)
            }


            ActivityCompat.requestPermissions(context, permisos, idCode)
        }
        else{
            iniciarActualizacionesDeUbicacion()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            Datos.MY_PERMISSION_REQUEST_LOCATION -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) && (grantResults[1] == PackageManager.PERMISSION_GRANTED) ) {
                    Toast.makeText(this, "!Gracias", Toast.LENGTH_SHORT).show()
                    iniciarActualizacionesDeUbicacion()

                } else {
                    Toast.makeText(this, "Funcionalidades Limitadas", Toast.LENGTH_SHORT).show()
                }
                return
            }
            else -> {

            }
        }
    }

    private fun colocarMarcador(direccion: String) {
        val geocoder = Geocoder(this@MapaConGoogle)

        try {
            val addresses = geocoder.getFromLocationName(direccion, 1)
            if (addresses != null) {
                if (addresses.isNotEmpty()) {
                    val location = addresses[0]
                    val latLng = LatLng(location.latitude, location.longitude)
                    var distancia = 0.0

                    mMap.addMarker(MarkerOptions().position(latLng).title(direccion))
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
                    distancia = calcularDistancia(latLng,posicionActual)
                    Toast.makeText(this, "la distancia entre el punto de partida y este es: ${distancia}km",
                        Toast.LENGTH_SHORT).show()

                } else {
                    // No se encontró la dirección
                    // Puedes mostrar un mensaje al usuario aquí
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            // Manejar errores de geocodificación
        }
    }

    private fun calcularDistancia(latLng1: LatLng, latLng2: LatLng): Double {
        val earthRadius = 6371 // Radio de la Tierra en kilómetros

        val dLat = Math.toRadians(latLng2.latitude - latLng1.latitude)
        val dLon = Math.toRadians(latLng2.longitude - latLng1.longitude)

        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(latLng1.latitude)) * Math.cos(Math.toRadians(latLng2.latitude)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)

        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        val distance = earthRadius * c

        return distance

    }

    private fun iniciarActualizacionesDeUbicacion() {
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, // Establece el nivel de precisión
            15000 // Intervalo de actualización en milisegundos
        ).apply {
            setMinUpdateIntervalMillis(12000) // Intervalo más rápido en milisegundos
        }.build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation
                if (location != null) {
                    latitud = location.latitude
                    longitud = location.longitude
                    posicionActual = LatLng(latitud, longitud)

                    // Actualiza el marcador y mueve la cámara en el mapa
                    mMap.addMarker(
                        MarkerOptions().position(posicionActual).title("Tu ubicación actual")
                    )
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(posicionActual, 10F))
                }
            }
        }

        // Inicia las actualizaciones de ubicación
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
        }
    }

    fun loadJSONFromAsset(): String? {
        var json: String? = null
        try {
            val isStream: InputStream = assets.open("locations.json")
            val size:Int = isStream.available()
            val buffer = ByteArray(size)
            isStream.read(buffer)
            isStream.close()
            json = String(buffer, Charsets.UTF_8)
        } catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }

}