package com.example.taller3_eltriangulo.Logica

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.taller3_eltriangulo.Datos.Usuario
import com.example.taller3_eltriangulo.R
import com.example.taller3_eltriangulo.databinding.ActivityMapaUsuarioBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MapaUsuario : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var binding: ActivityMapaUsuarioBinding
    private lateinit var mMap: GoogleMap
    private lateinit var database: DatabaseReference
    private lateinit var targetUserId: String
    private var targetUserMarker: Marker? = null
    private var lineBetweenUsers: Polyline? = null

    private var currentUserLocation: LatLng? = null
    private var targetUserLocation: LatLng? = null

    private lateinit var locationCallback: LocationCallback
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapaUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetUserId = intent.getStringExtra("userId") ?: ""
        if (targetUserId.isEmpty()) {
            Toast.makeText(this, "Usuario inválido", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val mapFragment = supportFragmentManager.findFragmentById(R.id.detallesMapa) as SupportMapFragment
        mapFragment.getMapAsync(this)

        database = FirebaseDatabase.getInstance().reference

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation
                location?.let {
                    currentUserLocation = LatLng(it.latitude, it.longitude)
                    Log.d("Location", "Current User Location: $currentUserLocation")
                    updateLine()
                }
            }
        }

        getCurrentUserLocation()
        listenToTargetUserLocation()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Habilitar controles de zoom
        mMap.uiSettings.isZoomControlsEnabled = true

        // Habilitar gestos de zoom (incluyendo doble clic)
        mMap.uiSettings.isZoomGesturesEnabled = true

        // Habilitar mi ubicación si es posible
        enableMyLocation()
    }

    private fun enableMyLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                2000
            )
            return
        }
        mMap.isMyLocationEnabled = true
        mMap.uiSettings.isMyLocationButtonEnabled = true
    }

    private fun getCurrentUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2000
            )
            return
        }
        fusedLocationClient.requestLocationUpdates(
            LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).build(),
            locationCallback,
            null
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2000) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                enableMyLocation()
                getCurrentUserLocation()
            } else {
                Toast.makeText(this, "Permiso de ubicación negado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun listenToTargetUserLocation() {
        val targetUserRef = database.child("usuarios").child(targetUserId)
        targetUserRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val user = snapshot.getValue(Usuario::class.java)
                user?.let {
                    targetUserLocation = LatLng(it.latitud, it.longitud)
                    Log.d("Location", "Target User Location: $targetUserLocation")
                    updateTargetUserMarker(it)
                    updateLine()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Manejar error
                Log.e("UserDetailActivity", "Error al escuchar usuario: ${error.message}")
            }
        })
    }

    private fun updateTargetUserMarker(user: Usuario) {
        targetUserLocation?.let { latLng ->
            if (targetUserMarker == null) {
                targetUserMarker = mMap.addMarker(
                    MarkerOptions()
                        .position(latLng)
                        .title("${user.nombre} ${user.apellido}")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                )
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12f))
            } else {
                targetUserMarker?.position = latLng
                targetUserMarker?.title = "${user.nombre} ${user.apellido}"
            }
        }
    }

    private fun updateLine() {
        if (currentUserLocation != null && targetUserLocation != null) {
            if (lineBetweenUsers != null) {
                lineBetweenUsers?.remove()
            }

            val polylineOptions = PolylineOptions()
                .add(currentUserLocation)
                .add(targetUserLocation)
                .color(ContextCompat.getColor(this, R.color.blue))  // Cambia el color si blue no existe
                .width(5f)
                .geodesic(true)

            lineBetweenUsers = mMap.addPolyline(polylineOptions)
            val boundsBuilder = LatLngBounds.Builder()
            boundsBuilder.include(currentUserLocation!!)
            boundsBuilder.include(targetUserLocation!!)
            val bounds = boundsBuilder.build()
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))

            // Calcular y mostrar la distancia
            calculateDistance()
        } else {
            Log.d("Location", "Ubicación del usuario actual o de destino es nula, no se puede trazar la línea.")
        }
    }

    private fun calculateDistance() {
        if (currentUserLocation != null && targetUserLocation != null) {
            val results = FloatArray(1)
            Location.distanceBetween(
                currentUserLocation!!.latitude,
                currentUserLocation!!.longitude,
                targetUserLocation!!.latitude,
                targetUserLocation!!.longitude,
                results
            )
            val distanceInMeters = results[0]
            val distanceInKm = distanceInMeters / 1000
            binding.distancia.text = "Distancia: %.2f km".format(distanceInKm)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::fusedLocationClient.isInitialized) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        }
    }
}
